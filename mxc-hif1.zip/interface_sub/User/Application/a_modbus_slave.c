//*****************************************************************************/
//* @file : a_modbus_slave.c
//* @author : gjkwon1 (gjkwon1@gst-in.com)*/
//* @brief : Modbus RTU Slave Protocol Task Implementation*/
//* @version : 0.1*/
//* @date : 2025. 12. 23.
//*****************************************************************************/
//* @copyright Copyright (c) 2024 Global Standard Technology Co., Ltd.*/
//*****************************************************************************/
//* All rights reserved.*/
//* This file is part of closed source software.*/
//* Unauthorized reproduction and redistribution prohibited.*/
//*****************************************************************************/

/*****************************************************************************/
/** INCLUDES *****************************************************************/
/*****************************************************************************/
#include "a_modbus_slave.h"
#include "a_dio.h"
#include "m_modbus.h"
#include "m_datablock.h"
#include <string.h>
/*****************************************************************************/
/** MACRO DEFINITIONS ********************************************************/
/*****************************************************************************/
#define UART_RX_BUFFER_SIZE 256
/*****************************************************************************/
/** DATATYPES ****************************************************************/
/*****************************************************************************/

/*****************************************************************************/
/** FUNCTION DECLARATIONS ****************************************************/
/*****************************************************************************/
// DIO functions declared in a_dio.h
/*****************************************************************************/
/** GLOBAL VARIABLES *********************************************************/
/*****************************************************************************/
extern UART_HandleTypeDef huart2;
/*****************************************************************************/
/** LOCAL VARIABLES **********************************************************/
/*****************************************************************************/
uint8_t uart_rx_buffer[UART_RX_BUFFER_SIZE];
static volatile uint8_t uart_rx_flag = 0;
static volatile uint16_t uart_rx_length = 0;


// 인터럽트에서 복사한 안전한 수신 버퍼
static uint8_t safe_rx_buffer[UART_RX_BUFFER_SIZE];
static volatile uint16_t safe_rx_length = 0;

// Modbus 데이터 영역
uint8_t coils[16] = {0};
uint8_t discreteInputs[16] = {0};
uint16_t holdingRegisters[64] = {0};
uint16_t inputRegisters[16] = {0};

// Modbus 송수신 버퍼
static uint8_t modbus_tx_buffer[256];
static Modbus_Rx_st modbus_rx_frame;

// Modbus Slave용 DataBlock
static DataBlock_st modbus_datablock = {
  .DInputs = discreteInputs,
  .DInputsCnt = 16,
  .DInputsStart = 0,
  
  .Coils = coils,
  .CoilsCnt = 16,
  .CoilsStart = 0,
  
  .Inputs = inputRegisters,
  .InputsCnt = 16,
  .InputsStart = 0,
  
  .Holdings = holdingRegisters,
  .HoldingsCnt = 4096,
  .HoldingsStart = 0,
};
/*****************************************************************************/
/** FUNCTION DEFINITIONS *****************************************************/
/*****************************************************************************/

/******************************************************************************
 * @brief UART Idle Interrupt Callback
 * @param Size: DMA 시작 이후 전송된 총 바이트 수 (circular mode에서는 현재 위치)
 * @note 인터럽트 콘텍스트에서 즉시 데이터를 안전한 버퍼로 복사
 *****************************************************************************/
uint16_t veiwdata[10] ={0,};
void HAL_UARTEx_RxEventCallback( UART_HandleTypeDef *huart, uint16_t Size )
{
  if( huart->Instance == huart2.Instance )
  {
//    uint16_t current_pos = UART_RX_BUFFER_SIZE - huart->hdmarx->Instance->CNDTR;
//    uint16_t data_length = 0;
//    volatile static uint8_t flag = 0;
//    volatile static uint8_t save_length = 0;
//    volatile static uint16_t old_pos = 0;  // 마지막으로 읽은 DMA 버퍼 위치
//    veiwdata[ 0 ] = current_pos;
//    veiwdata[ 4 ] = old_pos;
//    //    memset(safe_rx_buffer,0,128);
//
//
//      if( current_pos == old_pos )
//      {
//        if( flag > 0 )
//        {
//          memcpy( &safe_rx_buffer[ save_length ], &uart_rx_buffer[ 0 ], current_pos );
//          flag = 0;
//          save_length = 0;
//        }
//      }
//      else if( current_pos > old_pos )
//      {
//        if( flag > 0 )
//        {
//          memcpy( &safe_rx_buffer[ save_length ], &uart_rx_buffer[ 0 ], current_pos );
//          flag = 0;
//          save_length = 0;
//        }
//        else
//        {
//          // 정상 케이스: old_pos ~ current_pos
//          data_length = current_pos - old_pos;
//          veiwdata[ 1 ] = data_length;
//          if( data_length > 2 )
//             {
//          memcpy( safe_rx_buffer, &uart_rx_buffer[ old_pos ], data_length );
//             }
//        }
//      }
//      else if( current_pos < old_pos )
//      {
//        // Wrap-around 케이스: old_pos ~ 버퍼끝 + 버퍼시작 ~ current_pos
//        uint16_t len1 = UART_RX_BUFFER_SIZE - old_pos;
//        memcpy( safe_rx_buffer, &uart_rx_buffer[ old_pos ], len1 );
//        data_length += UART_RX_BUFFER_SIZE - old_pos;
//        save_length = data_length;
//        flag = 1;
//      }
//
//      old_pos = current_pos;  // 현재 위치를 다음 old_pos로 저장
//      // 유효한 데이터가 있을 때만 플래그 세팅
      if( Size > 0 )
      {
        safe_rx_length = Size;
        uart_rx_flag = SET;
      }
//
//
//      veiwdata[ 2 ] = flag;
//      veiwdata[ 3 ] = save_length;


//    HAL_UARTEx_ReceiveToIdle_DMA( &huart2, uart_rx_buffer, UART_RX_BUFFER_SIZE );
//    __HAL_DMA_DISABLE_IT(huart->hdmarx, DMA_IT_HT);
    // CIRCULAR 모드에서는 DMA가 자동으로 계속 동작하므로 재시작 불필요
      memcpy(uart_rx_buffer,safe_rx_buffer,UART_RX_BUFFER_SIZE);
      HAL_UARTEx_ReceiveToIdle_DMA( &huart2, safe_rx_buffer, UART_RX_BUFFER_SIZE );
//      __HAL_DMA_DISABLE_IT( huart2.hdmarx, DMA_IT_HT );
  }
}

/******************************************************************************
 * @brief UART 초기화
 *****************************************************************************/
void UartRxInit( void )
{
  // IDLE 인터럽트를 사용한 DMA 수신 시작
//  HAL_UARTEx_ReceiveToIdle_DMA( &huart2, uart_rx_buffer, UART_RX_BUFFER_SIZE );
  HAL_UARTEx_ReceiveToIdle_DMA( &huart2, safe_rx_buffer, UART_RX_BUFFER_SIZE );
  __HAL_DMA_DISABLE_IT( huart2.hdmarx, DMA_IT_HT );
  __HAL_UART_ENABLE_IT(&huart2,UART_IT_IDLE);
}

uint8_t SlaveIDCheck()
{
  uint8_t SlaveID=0;
  if( HAL_GPIO_ReadPin( ID_SET1_GPIO_Port, ID_SET1_Pin ) == GPIO_PIN_RESET )
  {
    SlaveID |= 1<<0;
  }
  else
  {
    SlaveID &= ~(1<<0);
  }
  if( HAL_GPIO_ReadPin( ID_SET2_GPIO_Port, ID_SET2_Pin ) == GPIO_PIN_RESET )
  {
    SlaveID |= 1<<1;
  }
  else
  {
    SlaveID &= ~(1<<1);
  }
return SlaveID;
}

/******************************************************************************
 * @brief ModbusSlaveTask - Modbus RTU Slave 프로토콜 처리
 *****************************************************************************/
Modbus_ExCode_et ex_code1;
  uint8_t slave_address = SlaveIDCheck();
void ModbusSlaveTask( void *argument )
{
  UartRxInit();
  DIO_Modbus_Init();
  
  // Modbus 슬레이브 주소 (필요시 수정)
  
  while( 1 )
  {
//    slave_address = SlaveIDCheck();
    // DIO 입력 상태 주기적으로 읽기
    DIO_Modbus_ReadInputs(modbus_rx_frame,slave_address);

    // UART 수신 데이터 확인
    if( uart_rx_flag )
    {
      uart_rx_flag = RESET;
      
      uint16_t data_length = safe_rx_length;
      
      // Modbus RTU 프레임 체크 (frame_format: 1=RTU, 2=ASCII, 3=TCP)
      Modbus_ExCode_et ex_code = MbSlaveCheckRequestFrame(
          'R', // RTU mode
        safe_rx_buffer,
        data_length,
        &modbus_datablock,
        &modbus_rx_frame
      );
      ex_code1 = ex_code;
      // 유효한 Modbus 프레임이고, 슬레이브 주소가 일치하는 경우
      if( ex_code == Modbus_ExCode_Normal
//    		  && modbus_rx_frame.MBAP_Header.Unit_ID == slave_address
			  )
      {
        uint16_t tx_length = 0;
        
        // Function code에 따른 응답 생성
        switch( modbus_rx_frame.function_code )
        {
          case Modbus_FunCode_Read_Holding_Reg:
            tx_length = modbus_slave_resp_read_holding_reg('R', &modbus_rx_frame, &modbus_datablock, modbus_tx_buffer);
            break;
            
          case Modbus_FunCode_Read_Input_Reg:
            tx_length = modbus_slave_resp_read_input_reg('R', &modbus_rx_frame, &modbus_datablock, modbus_tx_buffer);
            break;
            
          case Modbus_FunCode_Write_Single_Reg:
            tx_length = modbus_slave_resp_preset_holding_reg('R', &modbus_rx_frame, &modbus_datablock, modbus_tx_buffer);
            // Write 명령 후 즉시 GPIO 출력 업데이트
            DIO_Modbus_UpdateOutputs(modbus_rx_frame,slave_address);
            break;
            
          case Modbus_FunCode_Write_Multiple_Reg:
            tx_length = modbus_slave_resp_preset_multiple_reg('R', &modbus_rx_frame, &modbus_datablock, modbus_tx_buffer);
            // Write 명령 후 즉시 GPIO 출력 업데이트
            DIO_Modbus_UpdateOutputs(modbus_rx_frame,slave_address);
            break;
            
          default:
            tx_length = modbus_exception_response('R', &modbus_rx_frame, modbus_tx_buffer, Modbus_ExCode_Illegal_FunCode);
            break;
        }
        
        // 응답 전송
        if( tx_length > 0 )
        {
          HAL_GPIO_WritePin(UART2_DE_GPIO_Port, UART2_DE_Pin, GPIO_PIN_SET);
//          osDelay( 1 ); // DE 신호 안정화 대기 (필요시 조정)
          __disable_irq();
//          taskENTER_CRITICAL();
          HAL_UART_Transmit(&huart2, modbus_tx_buffer, tx_length, 50);
          __enable_irq();
//          osDelay( 1 ); // 전송 완료 대기 (필요시 조정)
//          taskEXIT_CRITICAL();
          HAL_GPIO_WritePin(UART2_DE_GPIO_Port, UART2_DE_Pin, GPIO_PIN_RESET);
        }
      }
    }
    osDelay( 1 );
  }
}
