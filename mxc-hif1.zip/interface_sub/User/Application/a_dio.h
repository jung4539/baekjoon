/*
 * a_dio.h
 *
 *  Created on: 2025. 12. 29.
 *      Author: gjkwon1PC
 */

#ifndef APPLICATION_A_DIO_H_
#define APPLICATION_A_DIO_H_

/*****************************************************************************/
/** INCLUDES *****************************************************************/
/*****************************************************************************/
#include "main.h"
#include <stdbool.h>
#include <stdint.h>
#include "m_modbus.h"


/*****************************************************************************/
/** MACRO DEFINITIONS ********************************************************/
/*****************************************************************************/
#define DIO_OUTPUT_COUNT    16
#define DIO_INPUT_COUNT     16

/*****************************************************************************/
/** FUNCTION DECLARATIONS ****************************************************/
/*****************************************************************************/
void DIO_Modbus_Init(void);
void DIO_Modbus_UpdateOutputs(Modbus_Rx_st modbus_rx_frame,uint8_t slave_address);
void DIO_Modbus_ReadInputs(Modbus_Rx_st modbus_rx_frame,uint8_t slave_address);


#endif /* APPLICATION_A_DIO_H_ */
