//*****************************************************************************/
//* @file : a_modbus_master.c
//* @author : gjkwon1 (gjkwon1@gst-in.com)
//* @brief : Modbus RTU Master Protocol Task Implementation
//* @version : 0.1
//* @date : 2026. 02. 20.
//*****************************************************************************/
//* @copyright Copyright (c) 2024 Global Standard Technology Co., Ltd.
//*****************************************************************************/

/*****************************************************************************/
/** INCLUDES *****************************************************************/
/*****************************************************************************/
#include "a_modbus_master.h"
#include "a_uart.h"
#include "m_modbus.h"
#include "m_datablock.h"
#include "main.h"
#include "cmsis_os2.h"
#include <string.h>

/*****************************************************************************/
/** MACRO DEFINITIONS ********************************************************/
/*****************************************************************************/
#define MBM_HOLDING_REGS_SIZE  256
#define MBM_INPUT_REGS_SIZE    256

/*****************************************************************************/
/** DATATYPES ****************************************************************/
/*****************************************************************************/

/*****************************************************************************/
/** FUNCTION DECLARATIONS ****************************************************/
/*****************************************************************************/
static bool ModbusMaster_ReadHoldingRegs(ModbusMasterConfig_t *config, uint16_t start_addr, uint16_t num_regs);
static bool ModbusMaster_SendRequest(ModbusMasterConfig_t *config, uint8_t func_code, 
                                     uint16_t start_addr, uint16_t num_regs);
static bool ModbusMaster_WriteRegisters(ModbusMasterConfig_t *config, 
                                        uint16_t start_addr, 
                                        uint16_t num_regs, 
                                        uint16_t *data);
static bool ModbusMaster_WriteSingleRegister(ModbusMasterConfig_t *config, 
                                             uint16_t reg_addr, 
                                             uint16_t value);


/*****************************************************************************/
/** GLOBAL VARIABLES *********************************************************/
/*****************************************************************************/
extern UART_HandleTypeDef hlpuart1;
extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;
extern UART_HandleTypeDef huart3;

/*****************************************************************************/
/** LOCAL VARIABLES **********************************************************/
/*****************************************************************************/
// Modbus Master configurations for each UART
static ModbusMasterConfig_t lpuart1_config = {
    .huart = &hlpuart1,
    .de_port = LPUART1_DE_GPIO_Port,
    .de_pin = LPUART1_DE_Pin,
    .slave_address = 1,
    .poll_interval = MBM_POLL_INTERVAL,
    .last_poll_tick = 0
};

static ModbusMasterConfig_t uart1_config = {
    .huart = &huart1,
    .de_port = USART1_DE_GPIO_Port,
    .de_pin = USART1_DE_Pin,
    .slave_address = 1,
    .poll_interval = MBM_POLL_INTERVAL,
    .last_poll_tick = 0
};

static ModbusMasterConfig_t uart2_config = {
    .huart = &huart2,
    .de_port = USART2_DE_GPIO_Port,
    .de_pin = USART2_DE_Pin,
    .slave_address = 1,
    .poll_interval = MBM_POLL_INTERVAL,
    .last_poll_tick = 0
};

static ModbusMasterConfig_t uart3_config = {
    .huart = &huart3,
    .de_port = USART3_DE_GPIO_Port,
    .de_pin = USART3_DE_Pin,
    .slave_address = 1,
    .poll_interval = MBM_POLL_INTERVAL,
    .last_poll_tick = 0
};

// Modbus data storage arrays for each channel
static uint16_t lpuart1_holding_regs[MBM_HOLDING_REGS_SIZE] = {0};
static uint16_t lpuart1_input_regs[MBM_INPUT_REGS_SIZE] = {0};

static uint16_t uart1_holding_regs[MBM_HOLDING_REGS_SIZE] = {0};
static uint16_t uart1_input_regs[MBM_INPUT_REGS_SIZE] = {0};

static uint16_t uart2_holding_regs[MBM_HOLDING_REGS_SIZE] = {0};
static uint16_t uart2_input_regs[MBM_INPUT_REGS_SIZE] = {0};

static uint16_t uart3_holding_regs[MBM_HOLDING_REGS_SIZE] = {0};
static uint16_t uart3_input_regs[MBM_INPUT_REGS_SIZE] = {0};

// Modbus data storage for each channel
static DataBlock_st lpuart1_datablock = {
    .Holdings = lpuart1_holding_regs,
    .HoldingsCnt = MBM_HOLDING_REGS_SIZE,
    .HoldingsStart = 0,
    .Inputs = lpuart1_input_regs,
    .InputsCnt = MBM_INPUT_REGS_SIZE,
    .InputsStart = 0,
    .Coils = NULL,
    .CoilsCnt = 0,
    .CoilsStart = 0,
    .DInputs = NULL,
    .DInputsCnt = 0,
    .DInputsStart = 0
};

static DataBlock_st uart1_datablock = {
    .Holdings = uart1_holding_regs,
    .HoldingsCnt = MBM_HOLDING_REGS_SIZE,
    .HoldingsStart = 0,
    .Inputs = uart1_input_regs,
    .InputsCnt = MBM_INPUT_REGS_SIZE,
    .InputsStart = 0,
    .Coils = NULL,
    .CoilsCnt = 0,
    .CoilsStart = 0,
    .DInputs = NULL,
    .DInputsCnt = 0,
    .DInputsStart = 0
};

static DataBlock_st uart2_datablock = {
    .Holdings = uart2_holding_regs,
    .HoldingsCnt = MBM_HOLDING_REGS_SIZE,
    .HoldingsStart = 0,
    .Inputs = uart2_input_regs,
    .InputsCnt = MBM_INPUT_REGS_SIZE,
    .InputsStart = 0,
    .Coils = NULL,
    .CoilsCnt = 0,
    .CoilsStart = 0,
    .DInputs = NULL,
    .DInputsCnt = 0,
    .DInputsStart = 0
};

static DataBlock_st uart3_datablock = {
    .Holdings = uart3_holding_regs,
    .HoldingsCnt = MBM_HOLDING_REGS_SIZE,
    .HoldingsStart = 0,
    .Inputs = uart3_input_regs,
    .InputsCnt = MBM_INPUT_REGS_SIZE,
    .InputsStart = 0,
    .Coils = NULL,
    .CoilsCnt = 0,
    .CoilsStart = 0,
    .DInputs = NULL,
    .DInputsCnt = 0,
    .DInputsStart = 0
};

/*****************************************************************************/
/** FUNCTION DEFINITIONS *****************************************************/
/*****************************************************************************/

/**
 * @brief Send Modbus RTU request using ModbusMasterQueryBuild
 * @param config Modbus master configuration
 * @param func_code Modbus function code
 * @param start_addr Starting register address
 * @param num_regs Number of registers to read/write
 * @return true if request sent successfully, false otherwise
 */
static bool ModbusMaster_SendRequest(ModbusMasterConfig_t *config, uint8_t func_code, 
                                     uint16_t start_addr, uint16_t num_regs)
{
  if (config == NULL || config->huart == NULL) return false;

    uint8_t tx_buffer[MBM_TX_BUFFER_SIZE];
    uint32_t tx_length = 0;
    DataBlock_st *datablock = NULL;
    
    // Get corresponding datablock
  if( config->huart->Instance == LPUART1 )
  {
    datablock = &lpuart1_datablock;
  }
  else if( config->huart->Instance == USART1 )
  {
    datablock = &uart1_datablock;
  }
  else if( config->huart->Instance == USART2 )
  {
    datablock = &uart2_datablock;
  }
  else if( config->huart->Instance == USART3 )
  {
    datablock = &uart3_datablock;
  }
  else
  {
    return false;
  }

    // Build Modbus RTU query frame using m_modbus function
    tx_length = ModbusMasterQueryBuild(
        'R',                        // Frame_Format: RTU mode
        config->slave_address,      // Slave_Address
        func_code,                  // Function_Code
        start_addr,                 // Start_Address
        num_regs,                   // No_Of_Items
        0,                          // aStart_Address (for Read/Write Multiple)
        0,                          // aNo_Of_Items (for Read/Write Multiple)
        datablock,                  // db
        tx_buffer                   // Query_Frame output buffer
    );

    if(tx_length == 0 || tx_length > MBM_TX_BUFFER_SIZE)
    {
        return false;
    }

    // Enable RS485 Driver (DE pin HIGH for transmit mode)
    HAL_GPIO_WritePin(config->de_port, config->de_pin, GPIO_PIN_SET);
    // Send request via UART
//    taskENTER_CRITICAL();
//    osDelay(1);
    __disable_irq();
    HAL_StatusTypeDef status = HAL_UART_Transmit(config->huart, tx_buffer, tx_length, 50);
    __enable_irq();
//    osDelay(1);
//    taskEXIT_CRITICAL();
    HAL_GPIO_WritePin(config->de_port, config->de_pin, GPIO_PIN_RESET);

    return (status == HAL_OK);
}

/**
 * @brief Write multiple holding registers to slave device
 * @param config Modbus master configuration
 * @param start_addr Starting register address
 * @param num_regs Number of registers to write
 * @param data Pointer to data array to write
 * @return true if request sent successfully, false otherwise
 */
static bool ModbusMaster_WriteRegisters(ModbusMasterConfig_t *config, 
                                        uint16_t start_addr, 
                                        uint16_t num_regs, 
                                        uint16_t *data)
{
    uint8_t tx_buffer[MBM_TX_BUFFER_SIZE];
    uint32_t tx_length = 0;
    DataBlock_st *datablock = NULL;
    
    if(data == NULL || num_regs == 0)
    {
        return false;
    }
    
    // Get corresponding datablock
    if(config->huart->Instance == LPUART1) datablock = &lpuart1_datablock;
    else if(config->huart->Instance == USART1) datablock = &uart1_datablock;
    else if(config->huart->Instance == USART2) datablock = &uart2_datablock;
    else if(config->huart->Instance == USART3) datablock = &uart3_datablock;
    else return false;
    
    // Verify datablock has enough space
    if(datablock->Holdings == NULL || 
       (start_addr + num_regs) > datablock->HoldingsCnt)
    {
        return false;
    }
    
    // Copy data to local datablock (for ModbusMasterQueryBuild to access)
    for(uint16_t i = 0; i < num_regs; i++)
    {
        datablock->Holdings[start_addr + i] = data[i];
    }
    
    // Build Modbus RTU write multiple registers query frame
    tx_length = ModbusMasterQueryBuild(
        'R',                               // Frame_Format: RTU mode
        config->slave_address,             // Slave_Address
        Modbus_FunCode_Write_Multiple_Reg, // Function_Code (0x10)
        start_addr,                        // Start_Address
        num_regs,                          // No_Of_Items
        0,                                 // aStart_Address (not used for FC16)
        0,                                 // aNo_Of_Items (not used for FC16)
        datablock,                         // db (contains data to write)
        tx_buffer                          // Query_Frame output buffer
    );
    
    if(tx_length == 0)
    {
        return false;
    }
    
    // Enable RS485 Driver (DE pin HIGH for transmit mode)
    HAL_GPIO_WritePin(config->de_port, config->de_pin, GPIO_PIN_SET);
    // Send request via UART
//    osDelay(1);
    __disable_irq();
    HAL_StatusTypeDef status = HAL_UART_Transmit(config->huart, tx_buffer, tx_length, 50);
    __enable_irq();
//    osDelay(1);
    // Disable RS485 Driver (DE pin LOW for receive mode)
    HAL_GPIO_WritePin(config->de_port, config->de_pin, GPIO_PIN_RESET);
    
    return (status == HAL_OK);
}




/*****************************************************************************/
/** FUNCTION DEFINITIONS *****************************************************/
/*****************************************************************************/

/**
 * @brief Read holding registers from slave device (blocking)
 * @param config Modbus master configuration
 * @param start_addr Starting register address to read
 * @param num_regs Number of registers to read
 * @return true if read successful, false otherwise
 * @note Sends FC03 request, waits 20ms for response, then parses and stores result.
 *       Result is stored in the channel's lpuart1/uart1/uart2/uart3 holding register array.
 *       RTU 응답에는 시작 주소가 없으므로 요청 시 사용한 start_addr을 직접 사용.
 */
static bool ModbusMaster_ReadHoldingRegs(ModbusMasterConfig_t *config,
                                         uint16_t start_addr,
                                         uint16_t num_regs)
{
    uint8_t rx_buffer[MBM_RX_BUFFER_SIZE];
    uint16_t rx_length = 0;
    Modbus_Rx_st modbus_rx_frame;
    DataBlock_st *datablock = NULL;

    if(config == NULL || config->huart == NULL) return false;

    // Get corresponding datablock
    if(config->huart->Instance == LPUART1)       datablock = &lpuart1_datablock;
    else if(config->huart->Instance == USART1)   datablock = &uart1_datablock;
    else if(config->huart->Instance == USART2)   datablock = &uart2_datablock;
    else if(config->huart->Instance == USART3)   datablock = &uart3_datablock;
    else return false;

    // 1. Send Read Holding Register request (FC03)
    if(!ModbusMaster_SendRequest(config, Modbus_FunCode_Read_Holding_Reg, start_addr, num_regs))
        return false;

    // 2. Wait for slave to respond (RS485 turnaround + slave processing time)
    osDelay(20);

    // 3. Receive response from UART ring buffer
    if(!Uart_GetData(config->huart, rx_buffer, &rx_length))
        return false;

    // 4. Parse response frame
    Modbus_ExCode_et ex_code = ModbusMasterResponseFrameParse(
        'R',
        rx_buffer,
        (uint32_t)rx_length,
        (volatile Modbus_Rx_st *)&modbus_rx_frame
    );

    if(ex_code != Modbus_ExCode_Normal)
        return false;

    if(modbus_rx_frame.MBAP_Header.Unit_ID != config->slave_address)
        return false;

    if(modbus_rx_frame.function_code & 0x80)    // exception response
        return false;

    if(modbus_rx_frame.function_code != Modbus_FunCode_Read_Holding_Reg)
        return false;

    if(modbus_rx_frame.byte_count == 0)
        return false;

    // 5. Store received data
    // RTU 응답에는 시작 주소가 없으므로 요청 시 사용한 start_addr을 직접 사용
    uint16_t num_returned = modbus_rx_frame.byte_count / 2;
    for(uint16_t i = 0; i < num_returned && i < num_regs; i++)
    {
        if((start_addr + i) < datablock->HoldingsCnt)
            datablock->Holdings[start_addr + i] = modbus_rx_frame.data_write[i];
    }

    return true;
}

//    	HAL_GPIO_WritePin(LPUART1_DE_GPIO_Port, LPUART1_DE_Pin, GPIO_PIN_SET);
//    	    // Send request via UART
//    	    osDelay(1);
//    	    __disable_irq();
//    	    HAL_UART_Transmit(&hlpuart1, (uint8_t *)"hello I'm herer\r\n", 20, 100);
//    	    __enable_irq();
//    	    osDelay(1);
//    	    // Disable RS485 Driver (DE pin LOW for receive mode)
//    	    HAL_GPIO_WritePin(LPUART1_DE_GPIO_Port, LPUART1_DE_Pin, GPIO_PIN_RESET);
/*****************************************************************************/
/** TASK IMPLEMENTATIONS *****************************************************/
/*****************************************************************************/

/**
 * @brief LPUART1 Modbus Master Task
 * usb board
 */
void MBM_LPuart1_Task(void *argument)
{
    // static uint16_t prev_value1 = 0;
    // static uint16_t prev_value2 = 0;
    // while(1)
    // {
    //     // Holding Register 읽기 (주소 106부터 1개)
	// 		ModbusMaster_ReadHoldingRegs(&lpuart1_config, MBS_Holding_Register_DI_1_Read_address, 1);
	// 		MBSDB.Holdings[MBS_Holding_Register_DI_1_Read_address] = lpuart1_holding_regs[MBS_Holding_Register_DI_1_Read_address];
	// 		osDelay(10);
	// 		ModbusMaster_ReadHoldingRegs(&lpuart1_config, MBS_Holding_Register_DI_2_Read_address, 1);
	// 		MBSDB.Holdings[MBS_Holding_Register_DI_2_Read_address] = lpuart1_holding_regs[MBS_Holding_Register_DI_2_Read_address];
	// 		osDelay(10);
    //     // 읽어온 값 사용 예시: uint16_t value = lpuart1_holding_regs[0];

    //     lpuart1_input_regs[MBS_Holding_Register_DO_1_Write_address] = MBSDB.Holdings[MBS_Holding_Register_DO_1_Write_address];
    //     if(prev_value1 != lpuart1_input_regs[MBS_Holding_Register_DO_1_Write_address])
    //     {
    //         // 변경된 값만 전송
    //         ModbusMaster_WriteRegisters(&lpuart1_config, MBS_Holding_Register_DO_1_Write_Start_address, MBS_Holding_Register_DO_1_Write_Num_of_coils, &lpuart1_input_regs[MBS_Holding_Register_DO_1_Write_address]);
    //         prev_value1 = lpuart1_input_regs[MBS_Holding_Register_DO_1_Write_address];
    //     }

    //     lpuart1_input_regs[MBS_Holding_Register_DO_2_Write_address] = MBSDB.Holdings[MBS_Holding_Register_DO_2_Write_address];
    //     if(prev_value2 != lpuart1_input_regs[MBS_Holding_Register_DO_2_Write_address])
    //     {
    //         // 변경된 값만 전송
    //         ModbusMaster_WriteRegisters(&lpuart1_config, MBS_Holding_Register_DO_2_Write_Start_address, MBS_Holding_Register_DO_2_Write_Num_of_coils, &lpuart1_input_regs[MBS_Holding_Register_DO_2_Write_address]);
    //         prev_value2 = lpuart1_input_regs[MBS_Holding_Register_DO_2_Write_address];
    //     }
    //     osDelay(80); // 20ms는 ReadHoldingRegs 내부에서 소비
    // }

      static uint16_t prev_do1 = 0;
    static uint16_t prev_do2 = 0;
    static uint16_t prev_di1 = 0xFFFF;  // 0xFFFF: 첫 주기 강제 업데이트
    static uint16_t prev_di2 = 0xFFFF;

    while(1)
    {
        // DI Read: 읽기 성공 + 값 변경 시에만 MBSDB 갱신
        if(ModbusMaster_ReadHoldingRegs(&lpuart1_config, MBS_Holding_Register_DI_1_Read_address, 1))
        {
            uint16_t new_val = lpuart1_holding_regs[MBS_Holding_Register_DI_1_Read_address];
            if(prev_di1 != new_val)
            {
                MBSDB.Holdings[MBS_Holding_Register_DI_1_Read_address] = new_val;
                prev_di1 = new_val;
            }
        }
        osDelay(10);

        if(ModbusMaster_ReadHoldingRegs(&lpuart1_config, MBS_Holding_Register_DI_2_Read_address, 1))
        {
            uint16_t new_val = lpuart1_holding_regs[MBS_Holding_Register_DI_2_Read_address];
            if(prev_di2 != new_val)
            {
                MBSDB.Holdings[MBS_Holding_Register_DI_2_Read_address] = new_val;
                prev_di2 = new_val;
            }
        }
        osDelay(10);

        // DO Write: 변경된 값만 슬레이브로 전송 (기존 로직 유지)
        uint16_t cur_do1 = MBSDB.Holdings[MBS_Holding_Register_DO_1_Write_address];
        if(prev_do1 != cur_do1)
        {
            ModbusMaster_WriteRegisters(&lpuart1_config,
                MBS_Holding_Register_DO_1_Write_Start_address,
                MBS_Holding_Register_DO_1_Write_Num_of_coils,
                &cur_do1);
            prev_do1 = cur_do1;
        }

        uint16_t cur_do2 = MBSDB.Holdings[MBS_Holding_Register_DO_2_Write_address];
        if(prev_do2 != cur_do2)
        {
            ModbusMaster_WriteRegisters(&lpuart1_config,
                MBS_Holding_Register_DO_2_Write_Start_address,
                MBS_Holding_Register_DO_2_Write_Num_of_coils,
                &cur_do2);
            prev_do2 = cur_do2;
        }

        osDelay(80);
    }
}

/**
 * @brief USART1 Modbus Master Task
 * backup interface
 */
void MBM_uart1_Task(void *argument)
{
    while(1)
    {
//        ModbusMaster_ProcessTask(&uart1_config);
        osDelay(10);
    }
}

/**
 * @brief USART2 Modbus Master Task
 * heating jacket
 */
void MBM_uart2_Task(void *argument)
{
    while(1)
    {
//        ModbusMaster_ProcessTask(&uart2_config);
        osDelay(10);
    }
}

/**
 * @brief USART3 Modbus Master Task
 * heating jacket
 */
void MBM_uart3_Task(void *argument)
{
    while(1)
    {
//        ModbusMaster_ProcessTask(&uart3_config);
        osDelay(10);
    }
}



/*****************************************************************************/
