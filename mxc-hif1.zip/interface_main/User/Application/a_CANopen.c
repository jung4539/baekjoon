/*****************************************************************************/
/* @file : a_template.h*******************************************************/
/* @author : gjkwon1 (gjkwon1@gst-in.com)*************************************/
/* @brief*********************************************************************/
/* @version : 0.1*************************************************************/
/* @date : 2025-05-07*********************************************************/
/*****************************************************************************/
/* @copyright Copyright (c) 2024 Global Standard Technology Co., Ltd.*********/
/*****************************************************************************/
/* All rights reserved.*******************************************************/
/* This file is part of closed source software.*******************************/
/* Unauthorized reproduction and redistribution prohibited.*******************/
/*****************************************************************************/

/*****************************************************************************/
/** INCLUDES *****************************************************************/
/*****************************************************************************/
#include "a_CANopen.h"
#include "CO_app_STM32.h"
#include "OD.h"
#include "cmsis_os2.h"


uint8_t SDO_DATA[ 256 ] = { 0, };

CANopenNodeSTM32 canOpenNodeSTM32;
extern CO_t *CO;
extern CAN_HandleTypeDef hcan1;
extern TIM_HandleTypeDef htim6;
extern osMutexId_t mtxid_ObjDictHandle;

uint16_t calculate_crc16( const uint8_t *data, size_t length )
{
  uint16_t crc = 0xFFFF;
  for( size_t i = 0; i < length; i++ )
  {
    crc ^= data[ i ];
    for( int j = 0; j < 8; j++ )
    {
      if( crc & 0x0001 ) crc = ( crc >> 1 ) ^ 0xA001;
      else
        crc >>= 1;
    }
  }
  return crc;
}
/******************************************************************************
 * @brief Write_SDO
 * process module -> distributed module
 * error code Reset & Dout command
 *****************************************************************************/
void Write_SDO( void )
{
  uint8_t mnt = canOpenNodeSTM32.canOpenStack->NMT->operatingState;

  switch( mnt )
  {
    case CO_NMT_INITIALIZING:
      break;
    case CO_NMT_STOPPED:
      break;

    case CO_NMT_PRE_OPERATIONAL:
    case CO_NMT_OPERATIONAL:

      break;
  }
}
/******************************************************************************
 * @brief Read_SDO
 * client -> server
 * error code(already set) + logic data(DI data + DI freq)
 *****************************************************************************/
void Read_SDO( void )
{
  uint8_t mnt = canOpenNodeSTM32.canOpenStack->NMT->operatingState;

  switch( mnt )
  {
    case CO_NMT_INITIALIZING:
      break;
    case CO_NMT_STOPPED:
      break;

    case CO_NMT_PRE_OPERATIONAL:
      break;
    case CO_NMT_OPERATIONAL:
      break;
  }
}

void SDO_Init()
{
}

/*****************************************************************************/
/* @brief update_logic_data***************************************************/
/*****************************************************************************/
void update_logic_data( void )
{
  uint8_t mnt = canOpenNodeSTM32.canOpenStack->NMT->operatingState;

  switch( mnt )
  {
    case CO_NMT_INITIALIZING:
      break;
    case CO_NMT_STOPPED:
      break;

    case CO_NMT_PRE_OPERATIONAL:
    case CO_NMT_OPERATIONAL:
      break;
  }


}
/*****************************************************************************/
/* @brief RPDO_update*********************************************************/
/* client -> server***********************************************************/
/* Dout command***************************************************************/
/*****************************************************************************/
void RPDO_update( void )
{
  uint8_t mnt = canOpenNodeSTM32.canOpenStack->NMT->operatingState;

  switch( mnt )
  {
    case CO_NMT_INITIALIZING:
      break;
    case CO_NMT_STOPPED:
      break;

    case CO_NMT_PRE_OPERATIONAL:
    case CO_NMT_OPERATIONAL:

      break;
  }
}
/*****************************************************************************/
/* @brief TPDO_update*********************************************************/
/* server -> client***********************************************************/
/* error flag(already set)****************************************************/
/*****************************************************************************/
void TPDO_update( void )
{
  uint8_t mnt = canOpenNodeSTM32.canOpenStack->NMT->operatingState;

  switch( mnt )
  {
    case CO_NMT_INITIALIZING:
      break;
    case CO_NMT_STOPPED:
      break;

    case CO_NMT_PRE_OPERATIONAL:
    case CO_NMT_OPERATIONAL:

      break;
  }
}
/*****************************************************************************/
/*@brief func_PDO_SYNC********************************************************/
/*originated from canopen_app_interrupt in CO_app_STM32.c*********************/
/*****************************************************************************/
bool_t func_PDO_SYNC( void )
{
  static uint32_t oldtick = 0;
  bool_t syncWas = false;

  if( !CO->nodeIdUnconfigured && CO->CANmodule->CANnormal )
  {
    /* get time difference since last function call */
    uint32_t nowtick = HAL_GetTick();
    uint32_t timeDifference_us = ( nowtick - oldtick ) * 1000;
    oldtick = nowtick;
#if( CO_CONFIG_SYNC ) & CO_CONFIG_SYNC_ENABLE
    syncWas = CO_process_SYNC( CO, timeDifference_us, NULL );
#endif
#if( CO_CONFIG_PDO ) & CO_CONFIG_RPDO_ENABLE
    CO_process_RPDO( CO, syncWas, timeDifference_us, NULL );
#endif
#if( CO_CONFIG_PDO ) & CO_CONFIG_TPDO_ENABLE
    CO_process_TPDO( CO, syncWas, timeDifference_us, NULL );
#endif
  }
  return syncWas;
}
/*****************************************************************************/
/* Can_GetBoardID*************************************************************/
/*****************************************************************************/
uint8_t Can_GetBoardID( void )
{
  uint8_t get_board_id = 0;
//  get_board_id = GPIOC->IDR;
//  get_board_id |= GPIOA->IDR << 4;
  get_board_id |= HAL_GPIO_ReadPin(CAN_ID0_GPIO_Port, CAN_ID0_Pin)<<4;
  get_board_id |= HAL_GPIO_ReadPin(CAN_ID1_GPIO_Port, CAN_ID1_Pin)<<5;
  get_board_id |= HAL_GPIO_ReadPin(CAN_ID2_GPIO_Port, CAN_ID2_Pin)<<6;
  get_board_id |= HAL_GPIO_ReadPin(CAN_ID3_GPIO_Port, CAN_ID3_Pin)<<7;
  get_board_id |= HAL_GPIO_ReadPin(CAN_ID4_GPIO_Port, CAN_ID4_Pin)<<0;
  get_board_id |= HAL_GPIO_ReadPin(CAN_ID5_GPIO_Port, CAN_ID5_Pin)<<1;
  get_board_id |= HAL_GPIO_ReadPin(CAN_ID6_GPIO_Port, CAN_ID6_Pin)<<2;
  get_board_id |= HAL_GPIO_ReadPin(CAN_ID7_GPIO_Port, CAN_ID7_Pin)<<3;
  return 255-get_board_id;
}
/*****************************************************************************/
/* Can_GetBaudrate************************************************************/
/*****************************************************************************/
uint16_t Can_GetBaudrate( void )
{
  uint8_t BR_SW = 15;
  uint16_t baudrate = 0;
//   BR_SW |= HAL_GPIO_ReadPin(CAN_BR0_GPIO_Port, CAN_BR0_Pin)<<0;
//   BR_SW |= HAL_GPIO_ReadPin(CAN_BR1_GPIO_Port, CAN_BR1_Pin)<<1;
//   BR_SW |= HAL_GPIO_ReadPin(CAN_BR2_GPIO_Port, CAN_BR2_Pin)<<2;
//   BR_SW |= HAL_GPIO_ReadPin(CAN_BR3_GPIO_Port, CAN_BR3_Pin)<<3;
   BR_SW = 15-BR_SW;

  switch( BR_SW )
  {
  default:
  case 0:
    baudrate = 1000;
    break;
  case 1:
    baudrate = 800;
    break;
  case 2:
    baudrate = 500;
    break;
  case 3:
    baudrate = 250;
    break;
  case 4:
    baudrate = 125;
    break;
  case 5:
    baudrate = 100;
    break;
  case 6:
    baudrate = 50;
    break;
  case 7:
    baudrate = 20;
    break;
  case 8:
    baudrate = 10;
    break;
  }

  return baudrate;
}
/******************************************************************************
 * @brief find_can_timing_params
 *
 *****************************************************************************/
uint32_t find_can_timing_params( uint16_t target_baudrate, uint8_t *TimeSeg1, uint8_t *TimeSeg2 )
{
  uint32_t Prescaler = 0;

  switch( target_baudrate )
  {
    case 1000:
      Prescaler = 5;
//      *TimeSeg1 = 13;
//      *TimeSeg2 = 2;
      *TimeSeg1 = 11;
      *TimeSeg2 = 4;
      break;
    default:
    case 800:
      Prescaler = 10;
      *TimeSeg1 = 8;
      *TimeSeg2 = 1;
      break;
    case 500:
      Prescaler = 10;
      *TimeSeg1 = 13;
      *TimeSeg2 = 2;
      break;
    case 250:
      Prescaler = 20;
      *TimeSeg1 = 13;
      *TimeSeg2 = 2;
      break;
    case 125:
      Prescaler = 40;
      *TimeSeg1 = 13;
      *TimeSeg2 = 2;
      break;
    case 50:
      Prescaler = 100;
      *TimeSeg1 = 13;
      *TimeSeg2 = 2;
      break;
    case 20:
      Prescaler = 250;
      *TimeSeg1 = 13;
      *TimeSeg2 = 2;
      break;
    case 10:
      Prescaler = 500;
      *TimeSeg1 = 13;
      *TimeSeg2 = 2;
      break;
  }
  return Prescaler;
}
/******************************************************************************
 * @brief parameter_BS1
 *
 *****************************************************************************/
uint32_t parameter_BS1( uint8_t tsg1 )
{
  uint32_t result = 0;
  switch( tsg1 )
  {
    case 1:
      result = CAN_BS1_1TQ;
      break;
    case 2:
      result = CAN_BS1_2TQ;
      break;
    case 3:
      result = CAN_BS1_3TQ;
      break;
    case 4:
      result = CAN_BS1_4TQ;
      break;
    case 5:
      result = CAN_BS1_5TQ;
      break;
    case 6:
      result = CAN_BS1_6TQ;
      break;
    case 7:
      result = CAN_BS1_7TQ;
      break;
    case 8:
      result = CAN_BS1_8TQ;
      break;
    case 9:
      result = CAN_BS1_9TQ;
      break;
    case 10:
      result = CAN_BS1_10TQ;
      break;
    case 11:
      result = CAN_BS1_11TQ;
      break;
    case 12:
      result = CAN_BS1_12TQ;
      break;
    case 13:
      result = CAN_BS1_13TQ;
      break;
    case 14:
      result = CAN_BS1_14TQ;
      break;
    case 15:
      result = CAN_BS1_15TQ;
      break;
    case 16:
      result = CAN_BS1_16TQ;
      break;
  }
  return result;
}
/******************************************************************************
 * @brief parameter_BS2
 *
 *****************************************************************************/
uint32_t parameter_BS2( uint8_t tsg2 )
{
  uint32_t result = 0;
  switch( tsg2 )
  {
    case 1:
      result = CAN_BS2_1TQ;
      break;
    case 2:
      result = CAN_BS2_2TQ;
      break;
    case 3:
      result = CAN_BS2_3TQ;
      break;
    case 4:
      result = CAN_BS2_4TQ;
      break;
    case 5:
      result = CAN_BS2_5TQ;
      break;
    case 6:
      result = CAN_BS2_6TQ;
      break;
    case 7:
      result = CAN_BS2_7TQ;
      break;
    case 8:
      result = CAN_BS2_8TQ;
      break;
  }
  return result;
}

void can_hw_init( void )
{
  uint8_t Seg1 = 0, Seg2 = 0;
  uint32_t target_baudrate = Can_GetBaudrate();
  uint32_t prescale = find_can_timing_params( target_baudrate, &Seg1, &Seg2 );

  hcan1.Instance = CAN1;
  hcan1.Init.Prescaler = prescale;
  hcan1.Init.Mode = CAN_MODE_NORMAL;
  hcan1.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan1.Init.TimeSeg1 = parameter_BS1( Seg1 );
  hcan1.Init.TimeSeg2 = parameter_BS2( Seg2 );
  hcan1.Init.TimeTriggeredMode = DISABLE;
  hcan1.Init.AutoBusOff = DISABLE;
  hcan1.Init.AutoWakeUp = ENABLE;
  hcan1.Init.AutoRetransmission = ENABLE;
  hcan1.Init.ReceiveFifoLocked = DISABLE;
  hcan1.Init.TransmitFifoPriority = ENABLE;

  if( HAL_CAN_Init( &hcan1 ) != HAL_OK )
  {
    // todo global alarm can error
    Error_Handler();
  }
}
/*****************************************************************************/
/* CanopenNodeInit************************************************************/
/*****************************************************************************/
void CanopenNodeInit( void )
{
  canOpenNodeSTM32.CANHandle = &hcan1;
  canOpenNodeSTM32.HWInitFunction = can_hw_init;
  canOpenNodeSTM32.timerHandle = &htim6;
  canOpenNodeSTM32.desiredNodeID = Can_GetBoardID();
  canOpenNodeSTM32.baudrate = Can_GetBaudrate();
  canopen_app_init( &canOpenNodeSTM32 );
}
/**
 * @brief Function implementing the CANopenPDO thread.
 * @param argument: Not used
 * @retval None
 */
void CANopenPDOTask( void *argument )
{
  /* USER CODE BEGIN CANopenPDOTask */
  uint32_t tick;
  /* Infinite loop */
  for( ;; )
  {

    tick = osKernelGetTickCount();
//    printf("Canopen_PDO_PDO_PDO_PDO_task\r\n");
    if( mtxid_ObjDictHandle != NULL )
    {
      if( osMutexAcquire( mtxid_ObjDictHandle, osWaitForever ) == osOK )
      {
        RPDO_update();
        func_PDO_SYNC();
        osMutexRelease( mtxid_ObjDictHandle );
        TPDO_update();
      }
    }
    osDelayUntil( tick + CANOPEN_PDO_INTERVAL );
  }
  /* USER CODE END CANopenPDOTask */
}
/**
 * @brief Function implementing the CANopenService thread.
 * @param argument: Not used
 * @retval None
 */
void CANopenServiceTask( void *argument )
{
  /* USER CODE BEGIN CANopenServiceTask */

  CanopenNodeInit();
  HAL_GPIO_WritePin( MODULE_RUN_GPIO_Port, MODULE_RUN_Pin, GPIO_PIN_SET );
//  SDO_Init1();
  uint32_t tick;
  /* Infinite loop */
  while( 1 )
  {
    tick = osKernelGetTickCount();
//    printf("Canopen_SDO_task\r\n");
    if( osMutexAcquire( mtxid_ObjDictHandle, osWaitForever ) == osOK )
    {
      Read_SDO();
      canopen_app_process();
      Write_SDO();
      osMutexRelease( mtxid_ObjDictHandle );
      HAL_GPIO_WritePin( CAN_RUN_GPIO_Port, CAN_RUN_Pin, !canOpenNodeSTM32.outStatusLEDRed );
      HAL_GPIO_WritePin( CAN_ERROR_GPIO_Port, CAN_ERROR_Pin, !canOpenNodeSTM32.outStatusLEDGreen );
    }
      osDelayUntil( tick + CANOPEN_PDO_INTERVAL );
  }
  /* USER CODE END CANopenServiceTask */
}
