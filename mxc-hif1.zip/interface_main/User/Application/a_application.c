/*****************************************************************************/
/* @file : a_application.c****************************************************/
/* @author : gjkwon1 (gjkwon1@gst-in.com)*************************************/
/* @brief*********************************************************************/
/* @version : 0.1*************************************************************/
/* @date : 2024-10-21*********************************************************/
/*****************************************************************************/
/* @copyright Copyright (c) 2024 Global Standard Technology Co., Ltd.*********/
/*****************************************************************************/
/* All rights reserved.*******************************************************/
/* This file is part of closed source software.*******************************/
/* Unauthorized reproduction and redistribution prohibited.*******************/
/*****************************************************************************/

/*****************************************************************************/
/** INCLUDES *****************************************************************/
/*****************************************************************************/

#include "a_application.h"
#include "cmsis_os2.h"
/*****************************************************************************/
/** DATATYPES ****************************************************************/
/*****************************************************************************/
osThreadAttr_t osThreadModbusMaster_lpuart1 = { .name = "ModbusMasterlpuart1Task", .stack_size = 1024*8, .priority = osPriorityNormal };
osThreadAttr_t osThreadModbusMaster_uart1   = { .name = "ModbusMasteruart1Task", .stack_size = 1024*8, .priority = osPriorityNormal };
osThreadAttr_t osThreadModbusSlave_uart4   = { .name = "ModbusMasteruart4Task", .stack_size = 1024*8, .priority = osPriorityNormal };
osThreadAttr_t osThreadModbusMaster_uart2   = { .name = "ModbusMasteruart2Task", .stack_size = 1024*8, .priority = osPriorityNormal };
osThreadAttr_t osThreadModbusMaster_uart3   = { .name = "ModbusMasteruart3Task", .stack_size = 1024*8, .priority = osPriorityNormal };

/* Definitions for CANopenPDO */
osThreadId_t CANopenPDOHandle;
const osThreadAttr_t CANopenPDO_attributes = { .name = "CANopenPDO", .stack_size = 1024 * 8, .priority = ( osPriority_t )osPriorityNormal, };
/* Definitions for CANopenService */
osThreadId_t CANopenServiceHandle;
const osThreadAttr_t CANopenService_attributes = { .name = "CANopenService", .stack_size = 1024 * 8, .priority = ( osPriority_t )osPriorityNormal, };

osMutexId_t mtxid_ObjDictHandle;
const osMutexAttr_t mtxid_ObjDict_attributes = { .name = "mtxid_ObjDict" };
/*****************************************************************************/
/** FUNCTION DECLARATIONS ****************************************************/
/*****************************************************************************/
osThreadId_t ModbusMasterTask_LPuart1_Handle;
osThreadId_t ModbusSlaveTask_uart4_Handle;
osThreadId_t ModbusMasterTask_uart1_Handle;
osThreadId_t ModbusMasterTask_uart2_Handle;
osThreadId_t ModbusMasterTask_uart3_Handle;
/*****************************************************************************/
/** GLOBAL VARIABLES *********************************************************/
/*****************************************************************************/

/*****************************************************************************/
/** LOCAL VARIABLES **********************************************************/
/*****************************************************************************/

/*****************************************************************************/
/** FUNCTION DEFINITIONS *****************************************************/
/*****************************************************************************/

/******************************************************************************
 * @brief InitApplication
 *****************************************************************************/
void InitApplication( void )
{
  Uart_Init();
  Uart_StartReceive();

  mtxid_ObjDictHandle = osMutexNew( &mtxid_ObjDict_attributes );

  ModbusSlaveTask_uart4_Handle = osThreadNew( ( osThreadFunc_t )MBS_uart4_Task, NULL, &osThreadModbusSlave_uart4 );

  ModbusMasterTask_LPuart1_Handle = osThreadNew( ( osThreadFunc_t )MBM_LPuart1_Task, NULL, &osThreadModbusMaster_lpuart1 );
  ModbusMasterTask_uart1_Handle = osThreadNew( ( osThreadFunc_t )MBM_uart1_Task, NULL, &osThreadModbusMaster_uart1 );
  ModbusMasterTask_uart2_Handle = osThreadNew( ( osThreadFunc_t )MBM_uart2_Task, NULL, &osThreadModbusMaster_uart2 );
  ModbusMasterTask_uart3_Handle = osThreadNew( ( osThreadFunc_t )MBM_uart3_Task, NULL, &osThreadModbusMaster_uart3 );

  /* creation of CANopenPDO */
  CANopenPDOHandle = osThreadNew( CANopenPDOTask, NULL, &CANopenPDO_attributes );

  /* creation of CANopenService */
  CANopenServiceHandle = osThreadNew( CANopenServiceTask, NULL, &CANopenService_attributes );
}

