//*****************************************************************************/
//* @file : a_uart.c
//* @author : gjkwon1 (gjkwon1@gst-in.com)
//* @brief : UART DMA reception handler with IDLE interrupt (Circular mode)
//* @version : 0.1
//* @date : 2026. 02. 20.
//*****************************************************************************/
//* @copyright Copyright (c) 2024 Global Standard Technology Co., Ltd.
//*****************************************************************************/

/*****************************************************************************/
/** INCLUDES *****************************************************************/
/*****************************************************************************/
#include "a_uart.h"
#include "main.h"
#include <string.h>

/*****************************************************************************/
/** MACRO DEFINITIONS ********************************************************/
/*****************************************************************************/

/*****************************************************************************/
/** DATATYPES ****************************************************************/
/*****************************************************************************/

/*****************************************************************************/
/** FUNCTION DECLARATIONS ****************************************************/
/*****************************************************************************/
static UartChannel_t* GetChannelByUart(UART_HandleTypeDef *huart);

/*****************************************************************************/
/** GLOBAL VARIABLES *********************************************************/
/*****************************************************************************/
extern UART_HandleTypeDef hlpuart1;
extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;
extern UART_HandleTypeDef huart3;
extern UART_HandleTypeDef huart4;

/*****************************************************************************/
/** LOCAL VARIABLES **********************************************************/
/*****************************************************************************/
// Each UART has its own channel with DMA buffer, process buffer, and position tracking
static UartChannel_t lpuart1_channel = {0};
static UartChannel_t usart1_channel = {0};
static UartChannel_t usart2_channel = {0};
static UartChannel_t usart3_channel = {0};
static UartChannel_t uart4_channel = {0};

/*****************************************************************************/
/** FUNCTION DEFINITIONS *****************************************************/
/*****************************************************************************/

/**
 * @brief Get channel structure by UART handle
 */
static UartChannel_t* GetChannelByUart(UART_HandleTypeDef *huart)
{
    if(huart->Instance == LPUART1) return &lpuart1_channel;
    if(huart->Instance == USART1) return &usart1_channel;
    if(huart->Instance == USART2) return &usart2_channel;
    if(huart->Instance == USART3) return &usart3_channel;
    if(huart->Instance == UART4) return &uart4_channel;
    return NULL;
}

/**
 * @brief Initialize UART handler
 */
void Uart_Init(void)
{
    memset(&lpuart1_channel, 0, sizeof(UartChannel_t));
    memset(&usart1_channel, 0, sizeof(UartChannel_t));
    memset(&usart2_channel, 0, sizeof(UartChannel_t));
    memset(&usart3_channel, 0, sizeof(UartChannel_t));
    memset(&uart4_channel, 0, sizeof(UartChannel_t));
}

/**
 * @brief Start DMA reception for all UARTs (CIRCULAR mode - call once)
 */
void Uart_StartReceive(void)
{
    // Circular mode: DMA automatically wraps around
    HAL_UARTEx_ReceiveToIdle_DMA(&hlpuart1, lpuart1_channel.rx_buffer, UART_RX_BUFFER_SIZE);
    __HAL_DMA_DISABLE_IT(hlpuart1.hdmarx, DMA_IT_HT);

    HAL_UARTEx_ReceiveToIdle_DMA(&huart1, usart1_channel.rx_buffer, UART_RX_BUFFER_SIZE);
    __HAL_DMA_DISABLE_IT(huart1.hdmarx, DMA_IT_HT);

    HAL_UARTEx_ReceiveToIdle_DMA(&huart2, usart2_channel.rx_buffer, UART_RX_BUFFER_SIZE);
    __HAL_DMA_DISABLE_IT(huart2.hdmarx, DMA_IT_HT);

    HAL_UARTEx_ReceiveToIdle_DMA(&huart3, usart3_channel.rx_buffer, UART_RX_BUFFER_SIZE);
    __HAL_DMA_DISABLE_IT(huart3.hdmarx, DMA_IT_HT);

    HAL_UARTEx_ReceiveToIdle_DMA(&huart4, uart4_channel.rx_buffer, UART_RX_BUFFER_SIZE);
    __HAL_DMA_DISABLE_IT(huart4.hdmarx, DMA_IT_HT);
}

/**
 * @brief Get received data from UART channel
 * @param huart UART handle
 * @param data Destination buffer
 * @param length Pointer to store data length
 * @return true if data available, false otherwise
 */
bool Uart_GetData(UART_HandleTypeDef *huart, uint8_t *data, uint16_t *length)
{
    UartChannel_t *channel = GetChannelByUart(huart);
    
    if(channel == NULL || !channel->data_ready || data == NULL || length == NULL) {
        return false;
    }
    
    // Copy data from safe process buffer
    *length = channel->data_length;
    memcpy(data, channel->process_buffer, channel->data_length);
    
    // Clear flag
    channel->data_ready = 0;
    channel->data_length = 0;
    
    return true;
}

/**
 * @brief UART RX Event Callback (called when IDLE line detected or buffer full)
 * @note In CIRCULAR mode, DMA automatically continues as a ring buffer
 * @note This callback tracks old_pos and copies only new data to safe buffer
 * @param huart UART handle
 * @param Size Current DMA position (not length!)
 */
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
    UartChannel_t *channel = GetChannelByUart(huart);
    
    if(channel != NULL)
    {
        uint16_t current_pos = Size;
        uint16_t data_length = 0;
        
        // Calculate new data range in circular buffer and copy to safe buffer immediately
        if(current_pos > channel->old_pos)
        {
        	memset(channel->process_buffer,0,UART_RX_BUFFER_SIZE);
            // Normal case: old_pos ~ current_pos
            data_length = current_pos - channel->old_pos;
            memcpy(channel->process_buffer, &channel->rx_buffer[channel->old_pos], data_length);
        }
        else if(current_pos < channel->old_pos)
        {
            // Wrap-around case: old_pos ~ buffer_end + buffer_start ~ current_pos
            uint16_t len1 = UART_RX_BUFFER_SIZE - channel->old_pos;
            uint16_t len2 = current_pos;
            memcpy(channel->process_buffer, &channel->rx_buffer[channel->old_pos], len1);
            memcpy(&channel->process_buffer[len1], channel->rx_buffer, len2);
            data_length = len1 + len2;
        }
        else
        {
            // current_pos == old_pos: no new data or full buffer (rare case)
            // Conservatively copy entire buffer
            data_length = current_pos - channel->old_pos;
            memcpy(channel->process_buffer, channel->rx_buffer, data_length);
        }
        
        channel->old_pos = current_pos;  // Save current position as next old_pos
        
        // Set flag only when valid data exists
        if(data_length > 0 && data_length <= UART_RX_BUFFER_SIZE)
        {
            channel->data_length = data_length;
            channel->data_ready = 1;
        }
        
        // No need to restart DMA - CIRCULAR mode continues automatically
    }
}

/*****************************************************************************/
