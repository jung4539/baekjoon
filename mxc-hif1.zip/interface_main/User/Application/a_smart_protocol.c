//*****************************************************************************/
//* @file : a_smart_protocol.c
//* @author : gjkwon1 (gjkwon1@gst-in.com)
//* @brief : Smart Protocol implementation for temperature control
//* @version : 0.1
//* @date : 2026. 02. 11.
//*****************************************************************************/
//* @copyright Copyright (c) 2024 Global Standard Technology Co., Ltd.
//*****************************************************************************/

/*****************************************************************************/
/** INCLUDES *****************************************************************/
/*****************************************************************************/
#include "a_smart_protocol.h"
#include "main.h"
#include <string.h>

/*****************************************************************************/
/** MACRO DEFINITIONS ********************************************************/
/*****************************************************************************/

/*****************************************************************************/
/** DATATYPES ****************************************************************/
/*****************************************************************************/

/*****************************************************************************/
/** FUNCTION DECLARATIONS ****************************************************/
/*****************************************************************************/
static UART_HandleTypeDef* GetUartHandle(SmartUartInstance_t instance);
static bool SendPacketWithRetry(SmartProtocolHandle_t *handle, uint8_t *packet, uint16_t length);
static bool WaitForResponse(SmartProtocolHandle_t *handle);

/*****************************************************************************/
/** GLOBAL VARIABLES *********************************************************/
/*****************************************************************************/
extern UART_HandleTypeDef hlpuart1;
extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;
extern UART_HandleTypeDef huart3;
extern UART_HandleTypeDef huart4;

/*****************************************************************************/
/** LOCAL VARIABLES **********************************************************/
/*****************************************************************************/

/*****************************************************************************/
/** FUNCTION DEFINITIONS *****************************************************/
/*****************************************************************************/

/**
 * @brief Get UART handle by instance
 */
static UART_HandleTypeDef* GetUartHandle( SmartUartInstance_t instance )
{
  switch( instance )
  {
    case SMART_UART_LPUART1:      return &hlpuart1;
    case SMART_UART_USART1:      return &huart1;
    case SMART_UART_USART2:      return &huart2;
    case SMART_UART_USART3:      return &huart3;
    case SMART_UART_UART4:      return &huart4;
    default:      return NULL;
  }
}

/**
 * @brief Initialize Smart Protocol handle
 */
void SmartProtocol_Init( SmartProtocolHandle_t *handle, SmartUartInstance_t uart_instance )
{
  if( handle == NULL ) return;

  memset( handle, 0, sizeof(SmartProtocolHandle_t) );

  handle->uart_instance = uart_instance;
  handle->huart = GetUartHandle( uart_instance );
  handle->state = SMART_STATE_IDLE;
  handle->retry_count = 0;
  handle->rx_index = 0;
  handle->dePort = USART2_DE_GPIO_Port;
  handle->dePin = USART2_DE_Pin;

}

/**
 * @brief Start DMA reception for Smart Protocol
 */
void SmartProtocol_StartReceive( SmartProtocolHandle_t *handle )
{
  if( handle == NULL || handle->huart == NULL ) return;

  HAL_UARTEx_ReceiveToIdle_DMA( handle->huart, handle->rx_buffer, SMART_RX_BUFFER_SIZE );
  __HAL_DMA_DISABLE_IT( handle->huart->hdmarx, DMA_IT_HT );
}

/**
 * @brief Calculate checksum (sum of STX to DATA, lower byte)
 */
uint8_t SmartProtocol_CalculateChecksum( uint8_t *buffer, uint16_t length )
{
  uint32_t sum = 0;
  for( uint16_t i = 0; i < length; i++ )
  {
    sum += buffer[ i ];
  }
  return ( uint8_t )( sum & 0xFF );
}

/**
 * @brief Build protocol packet
 * @return Packet length
 */
uint16_t SmartProtocol_BuildPacket( uint8_t *buffer, uint8_t id, uint8_t cmd, uint8_t add, uint8_t length, uint8_t *data )
{
  uint16_t index = 0;

  buffer[ index++ ] = SMART_STX;
  buffer[ index++ ] = id;
  buffer[ index++ ] = cmd;
  buffer[ index++ ] = add;
  buffer[ index++ ] = length;

  if( length > 0 && data != NULL )
  {
    memcpy( &buffer[ index ], data, length );
    index += length;
  }

  // Calculate checksum (STX to DATA)
  uint8_t cs = SmartProtocol_CalculateChecksum( buffer, index );
  buffer[ index++ ] = cs;
  buffer[ index++ ] = SMART_ETX;

  return index;
}

/**
 * @brief Parse received packet
 */
bool SmartProtocol_ParsePacket( SmartProtocolHandle_t *handle, uint8_t *buffer, uint16_t size )
{
  if( handle == NULL || buffer == NULL || size < 7 ) return false;

  // Verify STX and ETX
  if( buffer[ 0 ] != SMART_STX || buffer[ size - 1 ] != SMART_ETX )
  {
    return false;
  }

  // Extract fields
  uint8_t id = buffer[ 1 ];
  uint8_t cmd = buffer[ 2 ];
  uint8_t add = buffer[ 3 ];
  uint8_t length = buffer[ 4 ];
  uint8_t cs = buffer[ size - 2 ];

  // Verify checksum
  uint8_t calculated_cs = SmartProtocol_CalculateChecksum( buffer, size - 2 );
  if( cs != calculated_cs )
  {
    return false;
  }

  // Store response
  handle->response.received = true;
  handle->response.cmd = cmd;
  handle->response.channel = add;
  handle->response.data_len = length;

  if( length > 0 && length <= 64 )
  {
    memcpy( handle->response.data, &buffer[ 5 ], length );
  }

  handle->response.timestamp = HAL_GetTick();

  // Process data based on command
  switch( cmd )
  {
    case SMART_CMD_CURRENT_TEMP_1CH:
      if( length == 2 && add >= SMART_MIN_CHANNEL && add <= SMART_MAX_CHANNEL )
      {
        // Little endian: LSB first
        handle->current_temp[ add - 1 ] = buffer[ 5 ] | ( buffer[ 6 ] << 8 );
      }
      break;

    case SMART_CMD_CURRENT_TEMP_18CH:
      if( length == 36 )
      { // 18 channels * 2 bytes
        for( uint8_t i = 0; i < 18; i++ )
        {
          handle->current_temp[ i ] = buffer[ 5 + i * 2 ] | ( buffer[ 6 + i * 2 ] << 8 );
        }
      }
      break;

    case SMART_CMD_SV_TEMP_REQUEST:
      if( length == 36 )
      { // 18 channels * 2 bytes
        for( uint8_t i = 0; i < 18; i++ )
        {
          handle->sv_temp[ i ] = buffer[ 5 + i * 2 ] | ( buffer[ 6 + i * 2 ] << 8 );
        }
      }
      break;

    case SMART_CMD_ALARM_STATUS_REQUEST:
      if( length == 18 )
      { // 18 channels * 1 byte
        for( uint8_t i = 0; i < 18; i++ )
        {
          handle->alarm_status[ i ] = buffer[ 5 + i ];
        }
      }
      break;
  }

  return true;
}

/**
 * @brief Send packet with retry mechanism
 */
static bool SendPacketWithRetry(SmartProtocolHandle_t *handle, uint8_t *packet, uint16_t length)
{
    if(handle == NULL || handle->huart == NULL || packet == NULL) return false;

    handle->retry_count = 0;

//    while(handle->retry_count < SMART_MAX_RETRIES) {
        // Clear response flag
        handle->response.received = false;
        handle->state = SMART_STATE_WAIT_RESPONSE;

        HAL_GPIO_WritePin(handle->dePort, handle->dePin, GPIO_PIN_SET);
        // Send packet
        HAL_UART_Transmit(handle->huart, packet, length, 100);

        HAL_GPIO_WritePin(handle->dePort, handle->dePin, GPIO_PIN_RESET);
        // Wait for response
        if(WaitForResponse(handle)) {
            handle->state = SMART_STATE_IDLE;
            return true;
        }

//        handle->retry_count++;
//    }

    handle->state = SMART_STATE_ERROR;
    return false;
}

/**
 * @brief Wait for response with timeout
 */
static bool WaitForResponse(SmartProtocolHandle_t *handle)
{
    uint32_t start_tick = HAL_GetTick();

    while((HAL_GetTick() - start_tick) < SMART_RESPONSE_TIMEOUT_MS) {
        if(handle->response.received) {
            return true;
        }
        HAL_Delay(1);
    }

    return false;
}

/**
 * @brief Send Machine ON command
 */
bool SmartProtocol_SendMachineON( SmartProtocolHandle_t *handle, uint8_t channel )
{
  if( channel < SMART_MIN_CHANNEL || channel > SMART_MAX_CHANNEL ) return false;

  uint16_t len = SmartProtocol_BuildPacket( handle->tx_buffer, channel, SMART_CMD_MACHINE_ON, 0x00, 0, NULL );

  return SendPacketWithRetry( handle, handle->tx_buffer, len );
}

/**
 * @brief Send Machine OFF command
 */
bool SmartProtocol_SendMachineOFF( SmartProtocolHandle_t *handle, uint8_t channel )
{
  if( channel < SMART_MIN_CHANNEL || channel > SMART_MAX_CHANNEL ) return false;

  uint16_t len = SmartProtocol_BuildPacket( handle->tx_buffer, channel, SMART_CMD_MACHINE_OFF, 0x00, 0, NULL );

  return SendPacketWithRetry( handle, handle->tx_buffer, len );
}

/**
 * @brief Set SV temperature for 1 channel
 */
bool SmartProtocol_SetSVTemp_1Ch( SmartProtocolHandle_t *handle, uint8_t channel, uint16_t temp )
{
  if( channel < SMART_MIN_CHANNEL || channel > SMART_MAX_CHANNEL ) return false;

  uint8_t data[ 2 ];
  data[ 0 ] = temp & 0xFF;         // LSB (little endian)
  data[ 1 ] = ( temp >> 8 ) & 0xFF;  // MSB

  uint16_t len = SmartProtocol_BuildPacket( handle->tx_buffer, channel, SMART_CMD_SV_TEMP_SET_1CH, channel, 2, data );

  return SendPacketWithRetry( handle, handle->tx_buffer, len );
}

/**
 * @brief Set SV temperature for 18 channels
 */
bool SmartProtocol_SetSVTemp_18Ch( SmartProtocolHandle_t *handle, uint16_t *temp_array )
{
  uint8_t data[ 36 ]; // 18 channels * 2 bytes

  for( uint8_t i = 0; i < 18; i++ )
  {
    data[ i * 2 ] = temp_array[ i ] & 0xFF;         // LSB
    data[ i * 2 + 1 ] = ( temp_array[ i ] >> 8 ) & 0xFF; // MSB
  }

  uint16_t len = SmartProtocol_BuildPacket( handle->tx_buffer, SMART_ALL_CHANNELS, SMART_CMD_SV_TEMP_SET_18CH, 0x03, 36, data );

  return SendPacketWithRetry( handle, handle->tx_buffer, len );
}

/**
 * @brief Request current temperature for 1 channel
 */
bool SmartProtocol_RequestCurrentTemp_1Ch( SmartProtocolHandle_t *handle, uint8_t channel )
{
  if( channel < SMART_MIN_CHANNEL || channel > SMART_MAX_CHANNEL ) return false;

  uint16_t len = SmartProtocol_BuildPacket( handle->tx_buffer, channel, SMART_CMD_CURRENT_TEMP_1CH, 0x00, 0, NULL );

  return SendPacketWithRetry( handle, handle->tx_buffer, len );
}

/**
 * @brief Request current temperature for 18 channels
 */
bool SmartProtocol_RequestCurrentTemp_18Ch( SmartProtocolHandle_t *handle )
{
  uint16_t len = SmartProtocol_BuildPacket( handle->tx_buffer, SMART_ALL_CHANNELS, SMART_CMD_CURRENT_TEMP_18CH, 0x0B, 0, NULL );

  return SendPacketWithRetry( handle, handle->tx_buffer, len );
}

/**
 * @brief Request SV temperature
 */
bool SmartProtocol_RequestSVTemp( SmartProtocolHandle_t *handle )
{
  uint16_t len = SmartProtocol_BuildPacket( handle->tx_buffer, SMART_ALL_CHANNELS, SMART_CMD_SV_TEMP_REQUEST, 0x05, 0, NULL );

  return SendPacketWithRetry( handle, handle->tx_buffer, len );
}

/**
 * @brief Save settings to EEPROM
 */
bool SmartProtocol_SaveSettings( SmartProtocolHandle_t *handle )
{
  uint16_t len = SmartProtocol_BuildPacket( handle->tx_buffer, SMART_ALL_CHANNELS, SMART_CMD_SAVE, 0x06, 0, NULL );

  return SendPacketWithRetry( handle, handle->tx_buffer, len );
}

/**
 * @brief Request alarm status
 */
bool SmartProtocol_RequestAlarmStatus( SmartProtocolHandle_t *handle )
{
  uint16_t len = SmartProtocol_BuildPacket( handle->tx_buffer, SMART_ALL_CHANNELS, SMART_CMD_ALARM_STATUS_REQUEST, 0x01, 0, NULL );

  return SendPacketWithRetry( handle, handle->tx_buffer, len );
}

/**
 * @brief Reset alarm
 */
bool SmartProtocol_ResetAlarm( SmartProtocolHandle_t *handle )
{
  uint16_t len = SmartProtocol_BuildPacket( handle->tx_buffer, SMART_ALL_CHANNELS, SMART_CMD_ALARM_RESET, 0x0C, 0, NULL );

  return SendPacketWithRetry( handle, handle->tx_buffer, len );
}

/**
 * @brief Get current temperature for channel
 */
uint16_t SmartProtocol_GetCurrentTemp(SmartProtocolHandle_t *handle, uint8_t channel)
{
    if(channel < SMART_MIN_CHANNEL || channel > SMART_MAX_CHANNEL) return 0;
    return handle->current_temp[channel-1];
}

/**
 * @brief Get SV temperature for channel
 */
uint16_t SmartProtocol_GetSVTemp(SmartProtocolHandle_t *handle, uint8_t channel)
{
    if(channel < SMART_MIN_CHANNEL || channel > SMART_MAX_CHANNEL) return 0;
    return handle->sv_temp[channel-1];
}

/**
 * @brief Get alarm status for channel
 */
uint8_t SmartProtocol_GetAlarmStatus(SmartProtocolHandle_t *handle, uint8_t channel)
{
    if(channel < SMART_MIN_CHANNEL || channel > SMART_MAX_CHANNEL) return 0;
    return handle->alarm_status[channel-1];
}

/**
 * @brief UART RX callback (called from HAL_UARTEx_RxEventCallback)
 */
void SmartProtocol_RxCallback(SmartProtocolHandle_t *handle, uint8_t *data, uint16_t size)
{
    if(handle == NULL || data == NULL || size == 0) return;

    // Parse received packet
    SmartProtocol_ParsePacket(handle, data, size);
}

/*****************************************************************************/
