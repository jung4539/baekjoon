//*****************************************************************************/
//* @file : a_modbus_slave.c
//* @author : gjkwon1 (gjkwon1@gst-in.com)
//* @brief : Modbus RTU Slave Protocol Task Implementation
//* @version : 0.1
//* @date : 2026. 03. 07.
//*****************************************************************************/
//* @copyright Copyright (c) 2024 Global Standard Technology Co., Ltd.
//*****************************************************************************/

/*****************************************************************************/
/** INCLUDES *****************************************************************/
/*****************************************************************************/
#include "a_modbus_slave.h"
#include "a_uart.h"
#include "m_modbus.h"
#include "m_datablock.h"
#include "main.h"
#include "cmsis_os2.h"
#include <string.h>

/*****************************************************************************/
/** MACRO DEFINITIONS ********************************************************/
/*****************************************************************************/

/*****************************************************************************/
/** DATATYPES ****************************************************************/
/*****************************************************************************/

/*****************************************************************************/
/** FUNCTION DECLARATIONS ****************************************************/
/*****************************************************************************/

/*****************************************************************************/
/** GLOBAL VARIABLES *********************************************************/
/*****************************************************************************/
extern UART_HandleTypeDef huart4;
extern const DataBlock_st MBM_WRITE_DB[ MAX_DEVICE_COUNT ];
/*****************************************************************************/
/** LOCAL VARIABLES **********************************************************/
/*****************************************************************************/
// Modbus Slave data storage for UART4
static uint16_t uart4_holding_regs[MBS_HOLDING_REGS_SIZE] = {0};
static uint16_t uart4_input_regs[MBS_INPUT_REGS_SIZE] = {0};

// Modbus Slave DataBlock for UART4
static DataBlock_st uart4_slave_datablock = {
    .Holdings = uart4_holding_regs,
    .HoldingsCnt = MBS_HOLDING_REGS_SIZE,
    .HoldingsStart = 0,
    .Inputs = uart4_input_regs,
    .InputsCnt = MBS_INPUT_REGS_SIZE,
    .InputsStart = 0,
    .Coils = NULL,
    .CoilsCnt = 0,
    .CoilsStart = 0,
    .DInputs = NULL,
    .DInputsCnt = 0,
    .DInputsStart = 0
};

// Modbus Slave communication buffers
static uint8_t modbus_tx_buffer[UART_TX_BUFFER_SIZE];
static Modbus_Rx_st modbus_rx_frame;

// Register sync map: MBSDB → uart4 (PLC Read 요청 전 갱신할 주소 목록)
static const uint16_t mbs_to_uart4_map[] = {
    MBS_Holding_Register_DI_1_Read_address,
	MBS_Holding_Register_DI_2_Read_address,
};

// Register sync map: uart4 → MBSDB (PLC Write 요청 후 반영할 주소 목록)
static const uint16_t uart4_to_mbs_map[] = {
    MBS_Holding_Register_DO_1_Write_address,
	MBS_Holding_Register_DO_2_Write_address,
};

static void sync_uart4_from_mbs(void)
{
    for (uint16_t i = 0; i < sizeof(mbs_to_uart4_map) / sizeof(mbs_to_uart4_map[0]); i++)
    {
        uint16_t addr = mbs_to_uart4_map[i];
        uart4_holding_regs[addr] = MBSDB.Holdings[addr];
    }
}

static void sync_mbs_from_uart4(void)
{
    for (uint16_t i = 0; i < sizeof(uart4_to_mbs_map) / sizeof(uart4_to_mbs_map[0]); i++)
    {
        uint16_t addr = uart4_to_mbs_map[i];
        MBSDB.Holdings[addr] = uart4_holding_regs[addr];
    }
}

/*****************************************************************************/
/** FUNCTION DEFINITIONS *****************************************************/
/*****************************************************************************/

/**
 * @brief UART4 Modbus Slave Task
 * @param argument : Not used
 * @note Handles Modbus RTU Slave communication with PLC via UART4
 */
void MBS_uart4_Task(void *argument)
{
    uint8_t rx_buffer[MBS_RX_BUFFER_SIZE];
    uint16_t rx_length = 0;
    uint8_t slave_address = 1;  // Modbus Slave Address (can be configured)
    HAL_GPIO_WritePin(UART4_RE_GPIO_Port, UART4_RE_Pin, GPIO_PIN_SET); // recive enable
    while(1)
    {

        // Check for received UART data
        if(Uart_GetData(&huart4, rx_buffer, &rx_length))
        {
            // Check Modbus RTU frame validity
            Modbus_ExCode_et ex_code = MbSlaveCheckRequestFrame(
                'R',  // RTU mode
                rx_buffer,
                rx_length,
                &uart4_slave_datablock,
                &modbus_rx_frame
            );
            
            // Valid frame and matching slave address
            if(ex_code == Modbus_ExCode_Normal && 
               modbus_rx_frame.MBAP_Header.Unit_ID == slave_address)
            {
                uint16_t tx_length = 0;
                
                // Generate response based on function code
                switch(modbus_rx_frame.function_code)
                {
                    case Modbus_FunCode_Read_Holding_Reg:
                        sync_uart4_from_mbs();
                        tx_length = modbus_slave_resp_read_holding_reg(
                            'R', 
                            &modbus_rx_frame, 
                            &uart4_slave_datablock, 
                            modbus_tx_buffer
                        );
                        break;
                        
                    case Modbus_FunCode_Read_Input_Reg:
                        tx_length = modbus_slave_resp_read_input_reg(
                            'R',
                            &modbus_rx_frame, 
                            &uart4_slave_datablock, 
                            modbus_tx_buffer
                        );
                        break;
                        
                    case Modbus_FunCode_Write_Single_Reg:
                        tx_length = modbus_slave_resp_preset_holding_reg(
                            'R',
                            &modbus_rx_frame, 
                            &uart4_slave_datablock, 
                            modbus_tx_buffer
                        );
                        break;
                        
                    case Modbus_FunCode_Write_Multiple_Reg:
                        tx_length = modbus_slave_resp_preset_multiple_reg(
                            'R',
                            &modbus_rx_frame, 
                            &uart4_slave_datablock, 
                            modbus_tx_buffer
                        );
                        sync_mbs_from_uart4();
                        break;
                        
                    default:
                        tx_length = modbus_exception_response(
                            'R',
                            &modbus_rx_frame, 
                            modbus_tx_buffer, 
                            Modbus_ExCode_Illegal_FunCode
                        );
                        break;
                }
                
                // Transmit response
                if(tx_length > 0)
                {
                	HAL_GPIO_WritePin(UART4_RE_GPIO_Port, UART4_RE_Pin, GPIO_PIN_RESET);
                	// Enable RS485 Driver (TX mode)
                    HAL_GPIO_WritePin(UART4_DE_GPIO_Port, UART4_DE_Pin, GPIO_PIN_SET);
//                    osDelay(1);  // Driver enable stabilization delay
                    __disable_irq();
                    // Transmit Modbus response
                    HAL_UART_Transmit(&huart4, modbus_tx_buffer, tx_length, 50);
                     __enable_irq();
//                    osDelay(1);  // Wait for transmission complete
                    // Disable RS485 Driver (RX mode)
                    HAL_GPIO_WritePin(UART4_DE_GPIO_Port, UART4_DE_Pin, GPIO_PIN_RESET);
                    HAL_GPIO_WritePin(UART4_RE_GPIO_Port, UART4_RE_Pin, GPIO_PIN_SET);
                }
            }
        }
//        uint8_t data[10] ={1,2,3,4,5,6,7,8,9,10};
//            // Enable RS485 Driver (TX mode)
//        HAL_GPIO_WritePin(UART4_RE_GPIO_Port, UART4_RE_Pin, GPIO_PIN_RESET);
//            HAL_GPIO_WritePin(UART4_DE_GPIO_Port, UART4_DE_Pin, GPIO_PIN_SET);
//            osDelay(1);  // Driver enable stabilization delay
//            __disable_irq();
//            // Transmit Modbus response
//                	    HAL_UART_Transmit(&huart4, (uint8_t *)"Hello world", 12, 10);
//            osDelay(1);  // Wait for transmission complete
//             __enable_irq();
//            HAL_GPIO_WritePin(UART4_DE_GPIO_Port, UART4_DE_Pin, GPIO_PIN_RESET);
//            osDelay(1);  // Wait for transmission complete
//        HAL_GPIO_WritePin(UART4_RE_GPIO_Port, UART4_RE_Pin, GPIO_PIN_SET);
//        osDelay(1);  // Wait for transmission complete
        osDelay(10);  // Task scheduling delay
    }
}

/*****************************************************************************/
