//*****************************************************************************/
//* @file : a_uart.h
//* @author : gjkwon1 (gjkwon1@gst-in.com)
//* @brief : UART DMA reception handler with IDLE interrupt
//* @version : 0.1
//* @date : 2026. 02. 20.
//*****************************************************************************/
//* @copyright Copyright (c) 2024 Global Standard Technology Co., Ltd.
//*****************************************************************************/

#ifndef APPLICATION_A_UART_H_
#define APPLICATION_A_UART_H_

/*****************************************************************************/
/** INCLUDES *****************************************************************/
/*****************************************************************************/
#include "stm32l4xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

/*****************************************************************************/
/** MACRO DEFINITIONS ********************************************************/
/*****************************************************************************/
#define UART_RX_BUFFER_SIZE   254
#define UART_TX_BUFFER_SIZE   254

/*****************************************************************************/
/** DATATYPES ****************************************************************/
/*****************************************************************************/
typedef struct {
    uint8_t rx_buffer[UART_RX_BUFFER_SIZE];      // DMA circular buffer
    uint8_t process_buffer[UART_RX_BUFFER_SIZE]; // Safe buffer for processing
    volatile uint16_t data_length;               // Length of received data
    volatile uint8_t data_ready;                 // Data ready flag
    uint16_t old_pos;                            // Last read position in DMA buffer
} UartChannel_t;

/*****************************************************************************/
/** FUNCTION DECLARATIONS ****************************************************/
/*****************************************************************************/
void Uart_Init(void);
void Uart_StartReceive(void);
bool Uart_GetData(UART_HandleTypeDef *huart, uint8_t *data, uint16_t *length);

/*****************************************************************************/
/** GLOBAL VARIABLES *********************************************************/
/*****************************************************************************/

/*****************************************************************************/
#endif /* APPLICATION_A_UART_H_ */
