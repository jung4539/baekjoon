/*
 * a_CANopen.h
 *
 *  Created on: Sep 27, 2024
 *      Author: user
 */


#ifndef _A_CANOPEN_H_
#define _A_CANOPEN_H_

#ifdef __cplusplus
extern "C" {
#endif

/*****************************************************************************/
/** INCLUDES *****************************************************************/
/*****************************************************************************/
#include "main.h"
#include "CO_app_STM32.h"
#include "OD.h"
/*****************************************************************************/
/** MACRO DEFINITIONS ********************************************************/
/*****************************************************************************/

#define CANOPEN_PDO_INTERVAL 1

/*****************************************************************************/
/** DATATYPES ****************************************************************/
/*****************************************************************************/

/*****************************************************************************/
/** FUNCTION DECLARATIONS ****************************************************/
/*****************************************************************************/

//void CANopenPDOTask( void );
void CanopenLED( void );
//void CANopenServiceTask( void );

/*****************************************************************************/
/** GLOBAL VARIABLES *********************************************************/
/*****************************************************************************/

//extern osMutexId_t mtxid_ObjDict;

/*****************************************************************************/
/** LOCAL VARIABLES **********************************************************/
/*****************************************************************************/

/*****************************************************************************/
/** FUNCTION DEFINITIONS *****************************************************/
/*****************************************************************************/
void Write_SDO( void );
void reset_object_dicionary( void );
void Read_SDO( void );
void update_logic_data( void );
void RPDO_update( void );
bool_t func_PDO_SYNC( void );
void TPDO_update( void );
uint8_t Can_GetBoardID( void );
uint16_t Can_GetBaudrate( void );
uint32_t find_can_timing_params( uint16_t target_baudrate, uint8_t *TimeSeg1, uint8_t *TimeSeg2 );
uint32_t parameter_BS1( uint8_t tsg1 );
uint32_t parameter_BS2( uint8_t tsg2 );
void can_hw_init( void );
void CanopenNodeInit( void );
void CANopenPDOTask( void *argument );
void CANopenServiceTask( void *argument );

#ifdef __cplusplus
}
#endif

#endif /* _A_CANOPEN_H_ */
