//*****************************************************************************/
//* @file : a_smart_protocol.h
//* @author : gjkwon1 (gjkwon1@gst-in.com)
//* @brief : Smart Protocol definitions for multi-channel temperature control
//* @version : 0.1
//* @date : 2026. 02. 11.
//*****************************************************************************/
//* @copyright Copyright (c) 2024 Global Standard Technology Co., Ltd.
//*****************************************************************************/

#ifndef APPLICATION_A_SMART_PROTOCOL_H_
#define APPLICATION_A_SMART_PROTOCOL_H_

/*****************************************************************************/
/** INCLUDES *****************************************************************/
/*****************************************************************************/
#include "stm32l4xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

/*****************************************************************************/
/** MACRO DEFINITIONS ********************************************************/
/*****************************************************************************/
// Protocol constants
#define SMART_STX                       0x02
#define SMART_ETX                       0x03

// Channel addressing
#define SMART_MIN_CHANNEL               0x01
#define SMART_MAX_CHANNEL               0x20  // 32 channels
#define SMART_ALL_CHANNELS              0xFF

// Command codes
#define SMART_CMD_MACHINE_ON            0x01
#define SMART_CMD_MACHINE_OFF           0x02
#define SMART_CMD_SV_TEMP_SET_18CH      0x03
#define SMART_CMD_SV_TEMP_SET_1CH       0x04
#define SMART_CMD_SV_TEMP_REQUEST       0x05
#define SMART_CMD_SAVE                  0x06
#define SMART_CMD_ALARM_STATUS_REQUEST  0x07
#define SMART_CMD_CURRENT_TEMP_1CH      0x0A
#define SMART_CMD_CURRENT_TEMP_18CH     0x0B
#define SMART_CMD_ALARM_RESET           0x0C

// Alarm status codes (bitmap)
#define SMART_ALARM_NONE                0x00
#define SMART_ALARM_PCB_TEMP_HIGH       0x01
#define SMART_ALARM_HEATER_OPEN         0x02
#define SMART_ALARM_SENSOR_OPEN         0x04
#define SMART_ALARM_TEMP_HIGH           0x08
#define SMART_ALARM_TEMP_LOW            0x10
#define SMART_ALARM_OVER_CURRENT        0x20
#define SMART_ALARM_SV_LIMIT_TIME       0x40
#define SMART_ALARM_FAN_RPM_LOW         0x80

// Buffer sizes
#define SMART_MAX_PACKET_SIZE           128
#define SMART_RX_BUFFER_SIZE            256
#define SMART_MAX_CHANNELS              32

// Timeout and retry
#define SMART_RESPONSE_TIMEOUT_MS       100
#define SMART_MAX_RETRIES               5

/*****************************************************************************/
/** DATATYPES ****************************************************************/
/*****************************************************************************/
// Packet structure
typedef struct {
    uint8_t stx;            // Start byte (0x02)
    uint8_t id;             // Channel ID (0x01~0x20) or 0xFF for all
    uint8_t cmd;            // Command code
    uint8_t add;            // Address/channel number
    uint8_t length;         // Data length
    uint8_t data[64];       // Data payload
    uint8_t cs;             // Checksum (sum of STX~DATA, lower byte)
    uint8_t etx;            // End byte (0x03)
} SmartProtocolPacket_t;

// UART instance selection
typedef enum {
    SMART_UART_LPUART1 = 0,
    SMART_UART_USART1,
    SMART_UART_USART2,
    SMART_UART_USART3,
    SMART_UART_UART4,
    SMART_UART_MAX
} SmartUartInstance_t;

// Protocol state
typedef enum {
    SMART_STATE_IDLE = 0,
    SMART_STATE_WAIT_RESPONSE,
    SMART_STATE_PROCESSING,
    SMART_STATE_ERROR
} SmartProtocolState_t;

// Response structure
typedef struct {
    bool received;
    uint8_t cmd;
    uint8_t channel;
    uint16_t data_len;
    uint8_t data[64];
    uint32_t timestamp;
} SmartProtocolResponse_t;

// Protocol handle
typedef struct {
    UART_HandleTypeDef *huart;
    GPIO_TypeDef *dePort;
    uint16_t dePin;
    SmartUartInstance_t uart_instance;
    SmartProtocolState_t state;

    uint8_t tx_buffer[SMART_MAX_PACKET_SIZE];
    uint8_t rx_buffer[SMART_RX_BUFFER_SIZE];
    uint16_t rx_index;

    SmartProtocolResponse_t response;
    uint8_t retry_count;

    uint16_t rxDataLength;

    // Temperature data (0.1°C units)
    uint16_t current_temp[SMART_MAX_CHANNELS];
    uint16_t sv_temp[SMART_MAX_CHANNELS];
    uint8_t alarm_status[SMART_MAX_CHANNELS];

} SmartProtocolHandle_t;

/*****************************************************************************/
/** FUNCTION DECLARATIONS ****************************************************/
/*****************************************************************************/
// Initialization
void SmartProtocol_Init(SmartProtocolHandle_t *handle, SmartUartInstance_t uart_instance);
void SmartProtocol_StartReceive(SmartProtocolHandle_t *handle);

// Packet building and parsing
uint16_t SmartProtocol_BuildPacket(uint8_t *buffer, uint8_t id, uint8_t cmd,
                                    uint8_t add, uint8_t length, uint8_t *data);
bool SmartProtocol_ParsePacket(SmartProtocolHandle_t *handle, uint8_t *buffer, uint16_t size);
uint8_t SmartProtocol_CalculateChecksum(uint8_t *buffer, uint16_t length);

// Command functions
bool SmartProtocol_SendMachineON(SmartProtocolHandle_t *handle, uint8_t channel);
bool SmartProtocol_SendMachineOFF(SmartProtocolHandle_t *handle, uint8_t channel);
bool SmartProtocol_SetSVTemp_1Ch(SmartProtocolHandle_t *handle, uint8_t channel, uint16_t temp);
bool SmartProtocol_SetSVTemp_18Ch(SmartProtocolHandle_t *handle, uint16_t *temp_array);
bool SmartProtocol_RequestCurrentTemp_1Ch(SmartProtocolHandle_t *handle, uint8_t channel);
bool SmartProtocol_RequestCurrentTemp_18Ch(SmartProtocolHandle_t *handle);
bool SmartProtocol_RequestSVTemp(SmartProtocolHandle_t *handle);
bool SmartProtocol_SaveSettings(SmartProtocolHandle_t *handle);
bool SmartProtocol_RequestAlarmStatus(SmartProtocolHandle_t *handle);
bool SmartProtocol_ResetAlarm(SmartProtocolHandle_t *handle);

// Data access
uint16_t SmartProtocol_GetCurrentTemp(SmartProtocolHandle_t *handle, uint8_t channel);
uint16_t SmartProtocol_GetSVTemp(SmartProtocolHandle_t *handle, uint8_t channel);
uint8_t SmartProtocol_GetAlarmStatus(SmartProtocolHandle_t *handle, uint8_t channel);

// Callback for UART RX
void SmartProtocol_RxCallback(SmartProtocolHandle_t *handle, uint8_t *data, uint16_t size);

/*****************************************************************************/
/** GLOBAL VARIABLES *********************************************************/
/*****************************************************************************/

/*****************************************************************************/
/** LOCAL VARIABLES **********************************************************/
/*****************************************************************************/

/*****************************************************************************/
/** FUNCTION DEFINITIONS *****************************************************/
/*****************************************************************************/


#endif /* APPLICATION_A_SMART_PROTOCOL_H_ */
