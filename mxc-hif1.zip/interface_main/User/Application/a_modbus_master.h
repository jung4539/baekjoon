//*****************************************************************************/
//* @file : a_modbus_master.h
//* @author : gjkwon1 (gjkwon1@gst-in.com)
//* @brief : Modbus RTU Master Protocol Task Implementation
//* @version : 0.1
//* @date : 2026. 02. 20.
//*****************************************************************************/
//* @copyright Copyright (c) 2024 Global Standard Technology Co., Ltd.
//*****************************************************************************/

#ifndef APPLICATION_A_MODBUS_MASTER_H_
#define APPLICATION_A_MODBUS_MASTER_H_

/*****************************************************************************/
/** INCLUDES *****************************************************************/
/*****************************************************************************/
#include "stm32l4xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

/*****************************************************************************/
/** MACRO DEFINITIONS ********************************************************/
/*****************************************************************************/
#define MBM_TX_BUFFER_SIZE  256
#define MBM_RX_BUFFER_SIZE  256
#define MBM_POLL_INTERVAL   100  // ms

/*****************************************************************************/
/** DATATYPES ****************************************************************/
/*****************************************************************************/
typedef struct {
    UART_HandleTypeDef *huart;
    GPIO_TypeDef *de_port;
    uint16_t de_pin;
    uint8_t slave_address;
    uint16_t poll_interval;
    uint32_t last_poll_tick;
} ModbusMasterConfig_t;

/*****************************************************************************/
/** FUNCTION DECLARATIONS ****************************************************/
/*****************************************************************************/
// Task functions (implemented in a_modbus_master.c)
void MBM_LPuart1_Task(void *argument);
void MBM_uart1_Task(void *argument);
void MBM_uart2_Task(void *argument);
void MBM_uart3_Task(void *argument);

/*****************************************************************************/
/** GLOBAL VARIABLES *********************************************************/
/*****************************************************************************/

/*****************************************************************************/
#endif /* APPLICATION_A_MODBUS_MASTER_H_ */
